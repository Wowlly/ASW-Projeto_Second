<html>
    <head>
        <meta charset = "UTF-8">
        <title>homePage</title>
        
    </head>

    <body>

        <h1>PandemicOnline</h1>
        <p>HOMEPAGE</p>
    </body>

</html>