<html>
    <head>
        <meta charset = "UTF-8">
        <title>indexPage</title>
        <?php include 'create_db.php';?>
        
    </head>

    <body>

        <h1>PandemicOnline</h1>
        <form action="login.php" method="get">
            <input type="submit" value="Sign in">
        </form>   
        <form action="register.php" method="get">
            <input type="submit" value="Sign up">
        </form>
    </body>

</html>