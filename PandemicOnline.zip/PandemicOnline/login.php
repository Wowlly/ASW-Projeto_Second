<html>
    <head>
        <meta charset = "UTF-8">
        <title>loginPage</title>
        
    </head>

    <body>

        <h1>Pandemic</h1>
        <form action="home.php" action="post">
            <fieldset>
            <legend>Login:</legend>
                Username:<br>
                <input type="text" name="username" placeholder="user001"><br>
                Password:<br>
                <input type="password" name="password" placeholder="password"><br><br>
            <input type="submit" value="Submit">
            </fieldset>
        </form> 
    </body>

</html>

