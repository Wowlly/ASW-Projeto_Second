<?php
//this is a great place to add more buttons at the top of the admin panel... like this...
?>
<!-- <a href="<?=$us_url_root?>users/cron_manager.php"><div class="col-md-1 col-sm-3 col-xs-6 col-centered">
          <div class="panel panel-default">
              <i class="fa fa-server fa-2x"></i><br>Manage<br>Cron<br>Jobs</li>
          </div>
      </div></a> -->
