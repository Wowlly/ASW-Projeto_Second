<?php
/*Include your custom hooks here! Examples:
  $itemString = str_replace('{{lname}}',$user->data()->lname,$itemString); */
 ?>
